from create_trajectory import *

import xgboost as xgb
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.metrics import accuracy_score, roc_auc_score
import json
from sklearn.tree import DecisionTreeClassifier

os.environ["TOKENIZERS_PARALLELISM"] = "false"
parser.add_argument('--max_T', default = -1, type = int, help="If max_T is not -1, we use only the first max_T steps of the trajectory; otherwise, we use the full trajectory.")

def train_grid_search(model, param_grid, X_train, X_val, X_test, y_train, y_val, y_test, model_name, d_res):
    """
    Run a CV grid search (AUC-ROC metric) to choose hyperparameters, then
    retrain the best model on (train+val) and evaluate on the test set.
    
    Results are written into d_res[model_name].
    """
    cv_split = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)

    grid_search = GridSearchCV(
        estimator=model,
        param_grid=param_grid,
        scoring='roc_auc',
        cv=cv_split,
        n_jobs=-1,
        verbose=4
    )
    grid_search.fit(np.concatenate([X_train, X_val]), np.concatenate([y_train, y_val]))

    print(f"Best parameters for {model_name}:", grid_search.best_params_)
    print(f"Best score for {model_name}:", grid_search.best_score_)

    best_model = grid_search.best_estimator_
    
    d_res[model_name]["CV AUC score"] = grid_search.best_score_
    d_res[model_name]["Best parameters"] = grid_search.best_params_

    best_model.fit(np.concatenate([X_train, X_val]), np.concatenate([y_train, y_val]))
    y_pred = best_model.predict(X_test)
    y_pred_proba = best_model.predict_proba(X_test)[:, 1]

    d_res[model_name]["Test Accuracy"] = accuracy_score(y_test, y_pred)
    d_res[model_name]["Test AUC"] = roc_auc_score(y_test, y_pred_proba)
    
    return d_res

if __name__ == "__main__":
    args = parser.parse_args()

    l_eval_modes = ['reg', 'bin', 'nli']

    hparams = vars(args)

    top_k_val = hparams['top_k_val']
    batch_size_GCD = hparams['batch_size_GCD']
    num_steps_GCD = hparams['num_steps_GCD']
    exploration_strat = hparams['exploration_strat']

    print("Environment:")
    print("\tPython: {}".format(sys.version.split(" ")[0]))
    print("\tPyTorch: {}".format(torch.__version__))
    print("\tCUDA: {}".format(torch.version.cuda))
    print("\tCUDNN: {}".format(torch.backends.cudnn.version()))
    print("\tNumPy: {}".format(np.__version__))
    print("\tNode: {}".format(socket.gethostname()))

    print('Args:')
    for k, v in sorted(hparams.items()):
        print('\t{}: {}'.format(k, v))

    # Set seeds
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    device = 'cuda' if torch.cuda.is_available() else 'cpu'

        
    save_folder = f"{path_save_folder}/"

    out_dir = get_name_exp(exploration_strat, save_folder, args.output_dir, args.dataset, top_k_val, num_steps_GCD, args.noise_type, args.noise_level, args.alignment_metric, args.batch_size_GCD, args.seed, args.match_head, args.obj_direction)

    print("out_dir =", out_dir, flush=True)

    # Load sentence trajectories
    d_sentences_train = torch.load(out_dir+f'/d_new_sentences_train.pt', weights_only=False, map_location="cpu")
    d_sentences_val = torch.load(out_dir+f'/d_new_sentences_val.pt', weights_only=False, map_location="cpu")
    d_sentences_test = torch.load(out_dir+f'/d_new_sentences_test.pt', weights_only=False, map_location="cpu")

    # Binary target: 1 if example is noisy, else 0
    y_train = (np.array(d_sentences_train["true"])!=np.array(d_sentences_train["noisy"])).astype(float)
    y_val = (np.array(d_sentences_val["true"])!=np.array(d_sentences_val["noisy"])).astype(float)
    y_test = (np.array(d_sentences_test["true"])!=np.array(d_sentences_test["noisy"])).astype(float)

    # Load alignment score trajectories (N_examples x (T+1))
    mat_alignment_scores_train = torch.load(out_dir+"/mat_alignment_scores_train.pt", map_location="cpu")
    mat_alignment_scores_val = torch.load(out_dir+"/mat_alignment_scores_val.pt", map_location="cpu")
    mat_alignment_scores_test = torch.load(out_dir+"/mat_alignment_scores_test.pt", map_location="cpu")
    
    # Optionally truncate trajectories to only use the first max_T steps
    if args.max_T!=-1:
        mat_alignment_scores_train = mat_alignment_scores_train[:, :args.max_T+1]
        mat_alignment_scores_val = mat_alignment_scores_val[:, :args.max_T+1]
        mat_alignment_scores_test = mat_alignment_scores_test[:, :args.max_T+1]

    # Load text similarity if it exists
    test_load_cos_sim_text = os.path.exists(out_dir+f'/d_cos_sim_sentences_train.pt')
    if test_load_cos_sim_text:
        try:
            d_cos_sim_sentences_train = torch.load(out_dir+f'/d_cos_sim_sentences_train.pt', map_location="cpu")
            d_cos_sim_sentences_val = torch.load(out_dir+f'/d_cos_sim_sentences_val.pt', map_location="cpu")
            d_cos_sim_sentences_test = torch.load(out_dir+f'/d_cos_sim_sentences_test.pt', map_location="cpu")
        except:
            print("Fail loading the text cosine similarity at "+out_dir)
            test_load_cos_sim_text = False
        if args.max_T!=-1:
            for key in list(d_cos_sim_sentences_train.keys()):
                if key >= args.max_T:
                    del d_cos_sim_sentences_train[key]
            for key in list(d_cos_sim_sentences_val.keys()):
                if key >= args.max_T:
                    del d_cos_sim_sentences_val[key]
            for key in list(d_cos_sim_sentences_test.keys()):
                if key >= args.max_T:
                    del d_cos_sim_sentences_test[key]

    to_add_T = "" if args.max_T == -1 else f"_{args.max_T}"
    if os.path.exists(out_dir+f"/results{to_add_T}.json"):
        with open(out_dir+f"/results{to_add_T}.json", 'r') as file:
            d_res_i = json.load(file)
    else:
        d_res_i = {}

    if os.path.exists(out_dir+"/preds.pt"):
        d_preds = torch.load(out_dir+"/preds.pt", map_location = device)
    else:
        d_preds = {}

    # Define feature sets to use for training ("Alignment Score (0)" corresponds to the baseline, and "Alignment Score + Cosine Sim Text" to TRACED)
    l_feature_used = ["Alignment Score (0)"]

    if test_load_cos_sim_text:
        l_feature_used += ["Alignment Score + Cosine Sim Text"]
    else:
        print("Text Cosine Similarity not found for", out_dir, flush=True)

    print("l_feature_used:", l_feature_used, flush=True)
    
    # Build features and train classifiers for each feature set
    for feature_used in l_feature_used:
        print("Dataset Name:", feature_used, flush=True)

        if feature_used not in d_res_i:
            d_res_i[feature_used] = {}

        X_train = np.zeros((mat_alignment_scores_train.shape[0], 0), dtype=np.float32)
        X_val = np.zeros((mat_alignment_scores_val.shape[0], 0), dtype=np.float32)
        X_test = np.zeros((mat_alignment_scores_test.shape[0], 0), dtype=np.float32)

        if "Alignment Score (0)" in feature_used:
            X_train = np.concatenate([X_train, mat_alignment_scores_train[:, [0]].cpu().numpy()], 1)
            X_val = np.concatenate([X_val, mat_alignment_scores_val[:, [0]].cpu().numpy()], 1)
            X_test = np.concatenate([X_test, mat_alignment_scores_test[:, [0]].cpu().numpy()], 1)

        elif "Alignment Score +" in feature_used:
            X_train = np.concatenate([X_train, mat_alignment_scores_train.cpu().numpy()], 1)
            X_val = np.concatenate([X_val, mat_alignment_scores_val.cpu().numpy()], 1)
            X_test = np.concatenate([X_test, mat_alignment_scores_test.cpu().numpy()], 1)        

        if "Cosine Sim Text" in feature_used:
            if len(d_cos_sim_sentences_train)>0:
                X_cossim_text_train = torch.stack([d_cos_sim_sentences_train[i] for i in range(len(d_cos_sim_sentences_train))], 1)
                X_cossim_text_val = torch.stack([d_cos_sim_sentences_val[i] for i in range(len(d_cos_sim_sentences_val))], 1)
                X_cossim_text_test = torch.stack([d_cos_sim_sentences_test[i] for i in range(len(d_cos_sim_sentences_test))], 1)
            else:
                X_cossim_text_train = torch.zeros((mat_alignment_scores_train.shape[0], 0))
                X_cossim_text_val = torch.zeros((mat_alignment_scores_val.shape[0], 0))
                X_cossim_text_test = torch.zeros((mat_alignment_scores_test.shape[0], 0))

            X_train = np.concatenate([X_train, X_cossim_text_train.cpu().numpy()], 1)
            X_val = np.concatenate([X_val, X_cossim_text_val.cpu().numpy()], 1)
            X_test = np.concatenate([X_test, X_cossim_text_test.cpu().numpy()], 1)

        # Train and evaluate two classifiers:
        # - xgboost
        # - CART
        for method_name in ["xgboost", "CART"]:
            print("Method:", method_name, flush=True)
            if method_name not in d_res_i[feature_used]:
                d_res_i[feature_used][method_name] = {}

                if method_name == "xgboost":
                    param_grid = {
                        'max_depth': [3, 4, 5],
                        'learning_rate': [0.01, 0.05, 0.1, 0.5],
                        'n_estimators': [50, 100, 200, 400],
                    }
                    classifier = xgb.XGBClassifier(objective='binary:logistic', eval_metric='logloss')

                elif method_name == "CART":
                    param_grid = {
                        'max_depth': [1, 5, 10, None],
                    }
                    classifier = DecisionTreeClassifier(random_state=42)

                d_res_i[feature_used] = train_grid_search(classifier, param_grid, X_train, X_val, X_test, y_train, y_val, y_test, method_name, d_res_i[feature_used])

                with open(out_dir+f'/results{to_add_T}.json', 'w') as file:
                    json.dump(d_res_i, file, indent=4)

        # Fit the best-performing model (by CV AUC score) and save test predictions
        for method_name in ["xgboost", "CART"]:
            if feature_used not in d_preds:
                if d_res_i[feature_used]['xgboost']['CV AUC score'] > d_res_i[feature_used]['CART']['CV AUC score']:
                    best_params = d_res_i[feature_used]['xgboost']['Best parameters']
                    best_model = xgb.XGBClassifier(random_state=42, objective='binary:logistic', eval_metric='logloss', learning_rate = best_params['learning_rate'], max_depth = best_params['max_depth'], n_estimators = best_params['n_estimators'])
                else:
                    best_params = d_res_i[feature_used]['CART']['Best parameters']
                    best_model = DecisionTreeClassifier(random_state=42, max_depth = best_params['max_depth'])

                best_model.fit(np.concatenate([X_train, X_val]), np.concatenate([y_train, y_val]))
                y_pred = best_model.predict(X_test)
                d_preds[feature_used] = torch.Tensor(y_pred)
                torch.save(d_preds, out_dir+"/preds.pt")

    print("Path results =", out_dir+f'/results{to_add_T}.json', flush=True)
