import argparse
import json
import os
import random
import sys
import time
import numpy as np
import pickle
import socket
from pathlib import Path
from tqdm import tqdm
import torch
import torch.optim as optim
from lib.models.utils import algorithm_class_from_scratch
from lib.datasets.utils import get_dataset
from lib.utils.utils import path_serial
from utils_TRACED import get_clip_embeddings, get_name_exp, perform_alg, run_multi_gpu, inject_fine_grained_noise
from BLIP.models.blip_itm import blip_itm

os.environ["TOKENIZERS_PARALLELISM"] = "false"

parser = argparse.ArgumentParser(description="TRACED")

# Experiment Hyperparameters
parser.add_argument('--output_dir', type = str, default="TRACED")
parser.add_argument("--dataset", type=str, default="cifar100",
                    choices=['flickr30k', 'mscoco', 'mmimdb', 'fgb_attr',
                             'fgb_entity', 'fgb_quantity', 'fgb_action',
                             'fgb_relation'])
parser.add_argument("--noise_type", type=str, default="real", choices=["random", "noun", "cat", "fine_grained"])
parser.add_argument("--noise_level", type=float, default = 0.4)
parser.add_argument('--batch_size', default = 128, type = int)
parser.add_argument('--seed', default = 0, type = int)
parser.add_argument('--match_head', default = "itm", type = str, help="For BLIP, either itm or itc")

# TRACED Hyperparameters
parser.add_argument('--alignment_metric', default = "CLIP", type = str, help="Either CLIP or LEMON or LEMON_OPT or BLIP")
parser.add_argument('--top_k_val', default = 128, type = int, help="Number of candidate token change considered per coordinate using first-order information.")
parser.add_argument('--batch_size_GCD', default = 512, type = int, help="Number of candidate captions (N) considered for a given GCD step. For Fast GCD, N is set to top_k_val.")
parser.add_argument('--num_steps_GCD', default = 10, type = int, help="Number of exploration steps for GCD or Fast GCD. For the Elimination Algorithm, the number of steps is determined by the number of tokens.")
parser.add_argument('--exploration_strat', default = 0, type = int, help="Either 0 for Elimination Algorithm, 1 for GCD, and 2 for Fast GCD")
parser.add_argument('--obj_direction', default = "max", type = str, help="Either max or min.")

# LEMON specific hyperparameters
parser.add_argument("--path_lemon", type=str, default="None", help="Path to the res.pkl file containing the best hyperparameters for LEMoN-OPT.")
parser.add_argument("--dist_type", type=str, default="cosine", choices=["cosine", "euclidean"])
parser.add_argument('--normalize_d1', action = 'store_true', help = 'normalize CLIP sim by all possible labels. Only for CIFAR-10 and CIFAR-100')
parser.add_argument('--knn_k', default = 30, type = int)
parser.add_argument('--use_discrete_for_text', action = 'store_true', help = 'use the discrete metric for text comparisons')

with open("save_folder.txt", "r") as f:
    lines = f.readlines()
path_save_folder = lines[0].rstrip()

with open("path_checkpoints.txt", "r") as f:
    lines = f.readlines()
path_checkpoints = lines[0].rstrip()

if __name__ == "__main__":
    print("Is cuda available:", torch.cuda.is_available())
    n_gpus = torch.cuda.device_count()
    print("Number of GPUs:", n_gpus)
    args = parser.parse_args()
    print("args.seed=", args.seed)
    
    hparams = vars(args)

    top_k_val = hparams['top_k_val']
    batch_size_GCD = hparams['batch_size_GCD']
    num_steps_GCD = hparams['num_steps_GCD']
    exploration_strat = hparams['exploration_strat']

    print("Environment:")
    print("\tPython: {}".format(sys.version.split(" ")[0]))
    print("\tPyTorch: {}".format(torch.__version__))
    print("\tCUDA: {}".format(torch.version.cuda))
    print("\tCUDNN: {}".format(torch.backends.cudnn.version()))
    print("\tNumPy: {}".format(np.__version__))
    print("\tNode: {}".format(socket.gethostname()))

    print('Args:')
    for k, v in sorted(hparams.items()):
        print('\t{}: {}'.format(k, v))

    # Setting the seed
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    # Build the alignment model + tokenizer.
    if args.alignment_metric == "BLIP":
        if args.dataset == "flickr30k":
            path_model = f"{path_checkpoints}/BLIP_models/blip_vit_b_ft_flickr30k_itr/model_base_retrieval_flickr.pth"
        elif args.dataset == "mscoco" or args.dataset.startswith("fgb_"):
            path_model = f"{path_checkpoints}/BLIP_models/blip_vit_b_ft_coco_itr/model_base_retrieval_coco.pth"
        image_size = 224
        algorithm = blip_itm(pretrained=path_model, image_size=image_size, vit='base')
        tokenizer = algorithm.tokenizer
    else:
        algorithm, tokenizer = algorithm_class_from_scratch(
            "huggingface_clip", text_base_name='openai/clip-vit-base-patch32', img_base=None, return_tokenizer=True
        )
    start_input_id = tokenizer.encode('')[0]
    end_input_id = tokenizer.encode('')[1]

    # Load datasets with noise injection
    if args.noise_type in ["fine_grained"]:
        train_set, val_set, test_set = get_dataset(hparams['dataset'], args.seed, noisy_labels = True, percent_flips=0.0, 
                                                flip_type="random", return_combined_dataset = True)
    else:
        train_set, val_set, test_set = get_dataset(hparams['dataset'], args.seed, noisy_labels = True, percent_flips=args.noise_level, 
                                                    flip_type=args.noise_type, return_combined_dataset = True)
    
    if args.noise_type =="fine_grained":
        inject_fine_grained_noise(args.dataset, args.noise_level, args.seed, train_set, val_set, test_set, tokenizer, change_true=False)
        
    # In the case of the Elimination Algorithm, all the tokens are eliminated
    if exploration_strat == 0:
        num_steps_GCD = max([len(x.split()) for x in train_set.df["sentence"]])

    # For the FGCD algorithm, the number of candidates evaluated at each step is set to the number of possible token replacements for each coordinate.
    if exploration_strat == 2:
        batch_size_GCD = top_k_val

    # Experiment output directory setup
    save_folder = f"{path_save_folder}/"
    
    out_dir = get_name_exp(exploration_strat, save_folder, args.output_dir, args.dataset, top_k_val, num_steps_GCD, args.noise_type, args.noise_level, args.alignment_metric, args.batch_size_GCD, args.seed, args.match_head, args.obj_direction)
    out_dir = Path(out_dir)

    out_dir.mkdir(exist_ok = True, parents = True)

    name_dataset = hparams["dataset"]

    with open(out_dir/'args.json', 'w') as outfile:
        json.dump(vars(args), outfile, default=path_serial)

    algorithm = algorithm.eval().to(device)

    # LEMON / LEMON_OPT setup
    if "LEMON" in args.alignment_metric:
        if args.alignment_metric == "LEMON":
            # Default hyperparams LEMON FIX
            beta = 5
            gamma = 5
            tau_1_n = 0.1
            tau_1_m = 0.1
            tau_2_n = 5
            tau_2_m = 5
        elif args.alignment_metric == "LEMON_OPT":
            # Best hyperparameters found by running code from LEMoN paper
            noise_level_percent = int(args.noise_level*100)
            with open(args.path_lemon+"/res.pkl", 'rb') as f:
                res_lemon = pickle.load(f)
            best_params_lemon = res_lemon["agg_results"]["know_val_labels"]
            beta = best_params_lemon["beta"]
            gamma = best_params_lemon["gamma"]
            tau_1_n = best_params_lemon["tau_1_n"]
            tau_1_m = best_params_lemon["tau_1_m"]
            tau_2_n = best_params_lemon["tau_2_n"]
            tau_2_m = best_params_lemon["tau_2_m"]

        # Get embeddings of the subset of the training set
        compr_set = train_set
        emb_txt_tr, emb_img_tr, tr_text_labels, l_true_labels = get_clip_embeddings(compr_set, hparams["batch_size"], device, hparams["dataset"], args.alignment_metric, tokenizer, algorithm)
        emb_txt_tr = emb_txt_tr.to(device)
        emb_img_tr = emb_img_tr.to(device)
        # Train the KNN using Faiss
        if hparams['dist_type'] == 'cosine':
            dists_tr = 1 - (emb_txt_tr * emb_img_tr).sum(axis = 1)
        elif hparams['dist_type'] == 'euclidean':
            dists_tr = ((emb_txt_tr - emb_img_tr)**2).sum(axis = 1)

        index_txt = None
        index_img = None
        tr_text_labels = np.array(tr_text_labels)
        text_embeds_dataset_labels = None
    else:
        index_img = None
        index_txt = None
        train_indices_in_compr = None
        text_embeds_dataset_labels = None
        emb_txt_tr = None
        emb_img_tr = None
        tr_text_labels = None
        dists_tr = None
        beta = None
        gamma = None
        tau_1_n = None
        tau_2_n = None
        tau_1_m = None
        tau_2_m = None

    # A global or outer-scope variable to store the embedding outputs
    embedding_outputs = None

    train_indices_in_compr = np.arange(len(train_set))
    compr_set = train_set

    train_indices_in_compr = torch.Tensor(train_indices_in_compr).to(device)

    # Run the algorithm for each split: train, test, val
    for dataset_type in ["train", "test", "val"]:
        start_time = time.time()
        test_continue = False
        test_already_done = (os.path.exists(f"{out_dir}/mat_alignment_scores_{dataset_type}.pt")) or (os.path.exists(f"{out_dir}/d_new_sentences_{dataset_type}.pt"))
        if test_already_done:
            print(f"{out_dir}/mat_alignment_scores_{dataset_type}.pt")
            print("Already done!!!!", flush=True)
        if not test_already_done:
            test_continue = True
            if exploration_strat in [1,2]:
                for num_steps_GCD_test in range(num_steps_GCD, 100):
                    out_dir_test = get_name_exp(exploration_strat, save_folder, args.output_dir, args.dataset, top_k_val, num_steps_GCD_test, args.noise_type, args.noise_level, args.alignment_metric, args.batch_size_GCD, args.seed, args.match_head, args.obj_direction)
                    if os.path.exists(f"{out_dir_test}/mat_alignment_scores_{dataset_type}.pt"):
                        print(f"Experiment found for num_steps_GCD={num_steps_GCD_test}")
                        print(out_dir_test)
                        mat_alignment_scores = torch.load(f"{out_dir_test}/mat_alignment_scores_{dataset_type}.pt")
                        d_new_sentences = torch.load(f"{out_dir_test}/d_new_sentences_{dataset_type}.pt")
                        for key in list(d_new_sentences.keys()):
                            if type(key) == int and key >= num_steps_GCD:
                                del d_new_sentences[key]
                        torch.save(mat_alignment_scores[:, :num_steps_GCD+1], f"{out_dir}/mat_alignment_scores_{dataset_type}.pt")
                        torch.save(d_new_sentences, f"{out_dir}/d_new_sentences_{dataset_type}.pt")
                        test_continue = False
                        break
        if test_continue:                
            if dataset_type == "train":
                dataset = train_set
            elif dataset_type == "val":
                dataset = val_set
            elif dataset_type == "test":
                dataset = test_set
            
            start_time_perform_alg = time.time()
            l_results = run_multi_gpu(perform_alg, dataset, n_gpus, 1, algorithm, args, exploration_strat, batch_size_GCD, hparams, num_steps_GCD, start_input_id, top_k_val, name_dataset, tokenizer, end_input_id, index_img, index_txt, train_indices_in_compr, text_embeds_dataset_labels, emb_txt_tr, emb_img_tr, tr_text_labels, dists_tr, beta, gamma, tau_1_n, tau_2_n, tau_1_m, tau_2_m, args.match_head, args.obj_direction)
            time_alg = time.time() - start_time_perform_alg
            time_alg = {
                "runtime": time_alg,
            }
            file_path = os.path.join(out_dir, f"time_alg_{dataset_type}.json")
            with open(file_path, "w") as f:
                json.dump(time_alg, f, indent=4)
            print(f"Saved time_alg to {file_path}")

            mat_alignment_scores = torch.vstack([l_results[rank][0] for rank in range(n_gpus)])
            d_new_sentences = {}
            for rank in range(n_gpus):
                d_new_sentences_rank = l_results[rank][1]
                for key in d_new_sentences_rank:
                    if key not in d_new_sentences:
                        d_new_sentences[key] = []
                    d_new_sentences[key] += d_new_sentences_rank[key]

            torch.save(mat_alignment_scores, f"{out_dir}/mat_alignment_scores_{dataset_type}.pt")
            torch.save(d_new_sentences, f"{out_dir}/d_new_sentences_{dataset_type}.pt")
            print(f"Time {dataset_type}:", time.time() - start_time)

