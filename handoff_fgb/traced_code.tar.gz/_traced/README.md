# TRACED: Trajectory Creation for Error Detection

This repository contains the code used to run TRACED, as described in the ICLR 2026 paper "Seeing What’s Wrong: A Trajectory-Guided Approach to Caption Error Detection". 

## Installation

This code has been tested with Python 3.10.19 and the following packages:

```text
pytorch==2.4.0
torchvision==0.19.0
torchaudio==2.4.0
pytorch-cuda==12.4
numpy==2.2.6
tqdm==4.67.3
scikit-learn==1.7.2
xgboost==3.2.0
transformers==4.30.2
tokenizers==0.13.3
sentencepiece==0.2.1
pandas==2.3.3
pillow==12.1.1
pyyaml==6.0.3
requests==2.32.5
packaging==26.0
psutil==7.2.2
scipy==1.15.2
open_clip_torch==3.2.0
```

## Datasets

This code reuses some LEMoN functions mainly to load the datasets with random and noun noise types. 
Before using our code, please follow the steps described in the LEMoN repository (https://github.com/MLforHealth/LEMoN) to download and preprocess the datasets.

## Fine-grained noise benchmark

The fine-grained noise benchmark introduced in this paper is available for download:
- **Flickr30k**: [Link](https://drive.google.com/file/d/10HPILe4GzAnUbncXZWmrXWnhpBuGLfxT/view?usp=sharing)
- **MS COCO**: [Link](https://drive.google.com/file/d/1iqmKRJiupEK9kdUIyyFlf7MLJoc4h5oU/view?usp=sharing)

## Model Checkpoints

To use BLIP, please download the pretrained checkpoints first from the official BLIP repository (https://github.com/salesforce/BLIP):
- [BLIP Flickr30k checkpoint (model_base_retrieval_flickr.pth)](https://storage.googleapis.com/sfr-vision-language-research/BLIP/models/model_base_retrieval_flickr.pth)
- [BLIP COCO checkpoint (model_base_retrieval_coco.pth)](https://storage.googleapis.com/sfr-vision-language-research/BLIP/models/model_base_retrieval_coco.pth)

## Files/Folder

- `create_trajectory.py`: creates the caption trajectory and saves the image-caption alignment scores along the trajectory
- `add_text_sim.py`: computes and saves the (initial caption, current caption) semantic similarity along the trajectory
- `train_classifiers.py`: trains a classifier on the trajectory for error detection
- `utils_TRACED.py`: TRACED utilities
- `path_checkpoints.txt`: directory containing the saved BLIP checkpoints
- `path_datasets.txt`: directory where the datasets are stored
- `save_folder.txt`: directory where experiment outputs are written
- `lib`: useful scripts from the LEMoN repository (https://github.com/MLforHealth/LEMoN)
- `BLIP`: useful scripts from the BLIP repository (https://github.com/salesforce/BLIP)

## Usage

We provide below an example of how to apply TRACED-BLIP (ITM) on Flickr30k with fine-grained noise. 
To use LEMoN-OPT, first run the official LEMoN code to compute the optimal hyperparameters, then pass the directory containing the resulting `res.pkl` via `--path_lemon`.

### 1. Trajectory Creation

python create_trajectory.py --output_dir saved --dataset flickr30k --noise_type fine_grained --noise_level 0.5  --exploration_strat 0 --top_k_val 128 --alignment_metric BLIP --batch_size_GCD 256 --num_steps_GCD 10 --match_head itm --seed 0

### 2. Add Text Cosine Similarity

python add_text_sim.py --output_dir saved --dataset flickr30k --noise_type fine_grained --noise_level 0.5  --exploration_strat 0 --top_k_val 128 --alignment_metric BLIP --batch_size_GCD 256 --num_steps_GCD 10 --match_head itm --seed 0


### 3. Train Classifiers

python train_classifiers.py --output_dir saved --dataset flickr30k --noise_type fine_grained --noise_level 0.5  --exploration_strat 0 --top_k_val 128 --alignment_metric BLIP --batch_size_GCD 256 --num_steps_GCD 10 --match_head itm --seed 0

## Citing TRACED

If you find TRACED useful in your research, please consider citing our paper.

```
@inproceedings{
    afriat2026seeing,
    title={Seeing What{\textquoteright}s Wrong: A Trajectory-Guided Approach to Caption Error Detection},
    author={Gabriel Afriat and Ryan Lucas and Xiang Meng and Yufang Hou and Yada Zhu and Rahul Mazumder},
    booktitle={The Fourteenth International Conference on Learning Representations},
    year={2026},
    url={https://openreview.net/forum?id=73FGjnKu1P}
}
```