from torch.utils.data import DataLoader
import torch
from lib.utils.utils import normalize_vectors
import numpy as np
from tqdm import tqdm
import copy
import time
import os
from torch.utils.data import Subset
from lib.models.utils import load_tokenizer
import pickle
import torch.multiprocessing as mp
from transformers.modeling_outputs import BaseModelOutput
import json
import xgboost as xgb
from sklearn.tree import DecisionTreeClassifier

with open("path_datasets.txt", "r") as f:
    lines = f.readlines()
path_datasets = lines[0].rstrip()

def get_clip_embeddings(dataset, batch_size, device, name_dataset, alignment_metric, tokenizer, algorithm):
    """
    Iterates over the dataset to compute and return normalized text and image embeddings for each sample with labels
    """
    dataloader = DataLoader(
            dataset=dataset, batch_size=batch_size, num_workers=8)

    emb_img, emb_txt, tr_text_labels = [], [], []
    l_true_labels = []
    time_start = time.time()
    for idx, batch in tqdm(enumerate(dataloader), total = len(dataloader)):
        time_start = time.time()
        pixel_values = batch[0].to(device)

        text_labels = batch[2]    
        tr_text_labels += text_labels
        
        if alignment_metric=="BLIP":
            encodings = tokenizer(text_labels, padding='max_length', truncation=True, max_length=35, 
                                return_tensors="pt").to(device)
            input_ids = torch.tensor(encodings["input_ids"]).to(device)
            attention_mask = torch.tensor(encodings["attention_mask"]).to(device)
        else:
            encodings = tokenizer(
                    text_labels, padding="max_length", truncation=True)
            input_ids = torch.tensor(encodings["input_ids"]).to(device)
            attention_mask = torch.tensor(encodings["attention_mask"]).to(device)
        with torch.no_grad():
            emb_txt.append(algorithm.encode_text(input_ids, attention_mask).detach().cpu())
            emb_img.append(algorithm.encode_image(pixel_values).detach().cpu())
        l_true_labels += ((np.array(batch[2])==np.array(batch[1])).astype(np.float32)).tolist()

    emb_txt_tr = normalize_vectors(torch.concat(emb_txt))
    emb_img_tr = normalize_vectors(torch.concat(emb_img))
    return emb_txt_tr, emb_img_tr, tr_text_labels, l_true_labels

def GCD_embedings(algorithm, encodings, input_ids, attention_mask, emb_img, end_input_id, start_input_id, top_k_val, idx_end_caption, batch_size_GCD, idx_token_elim,
                 l_sample_idx, knn_k, index_img, index_txt, normalize_d1, train_indices_in_compr, batch_size, text_embeds_dataset_labels, emb_txt_tr, emb_img_tr, dist_type, use_discrete_for_text, tr_text_labels, dists_tr, beta, gamma, tau_1_n, tau_2_n, tau_1_m, tau_2_m, alignment_metric, match_head, obj_direction, test_debug=False):

    """
    Generate candidate captions for a GCD/FGCD step by using gradients w.r.t. token embeddings.

    Steps (high-level):
      1) Compute current alignment scores (CLIP dot-product / LEMON / BLIP).
      2) Backprop through the token-embedding layer to get a gradient signal per token position.
      3) For each position, select top-k token replacements suggested by the gradient.
      4) Sample token replacements and build a batch of candidate input_ids.
      5) Return both the new candidates and flattened tensors for later batched scoring.
    """

    global embedding_outputs

    def save_embedding_output(module, args, output):
        output.retain_grad()
        global embedding_outputs
        embedding_outputs = output

    if alignment_metric == "BLIP":
        hook_handle = algorithm.text_encoder.embeddings.word_embeddings.register_forward_hook(save_embedding_output)
        current_scores = algorithm.forward_after_tokenizer(emb_img, input_ids, attention_mask, match_head=match_head)
        if match_head == "itm":
            current_scores = torch.nn.functional.softmax(current_scores,dim=1)[:,1]
    else:
        hook_handle = algorithm.text_model.embeddings.token_embedding.register_forward_hook(save_embedding_output)

        emb_txt = algorithm.encode_text(input_ids, attention_mask)

        emb_txt = normalize_vectors(emb_txt)

        if "LEMON" in alignment_metric:
            current_scores = compute_lemon_score(l_sample_idx, emb_img, emb_txt, knn_k, index_img, index_txt, normalize_d1, train_indices_in_compr, batch_size, text_embeds_dataset_labels, emb_txt_tr, emb_img_tr, dist_type, use_discrete_for_text, tr_text_labels, dists_tr, beta, gamma, tau_1_n, tau_2_n, tau_1_m, tau_2_m, idx_end_caption.device)
        else:
            current_scores = emb_txt[:,None,:].bmm(emb_img[:, :, None])[:, 0, 0]

    obj = current_scores.sum()
    if obj_direction=="min":
        obj *= -1
    obj.backward()
    hook_handle.remove()
    
    if alignment_metric == "BLIP":
        delta_obj = embedding_outputs.matmul(algorithm.text_encoder.embeddings.word_embeddings.weight.T[None])
    else:
        delta_obj = embedding_outputs.matmul(algorithm.text_model.embeddings.token_embedding.weight.T[None])

    delta_obj[(input_ids==start_input_id)] = -np.inf
    max_delta_per_pos, idx_max_per_pos = torch.topk(delta_obj, top_k_val, 2)

    if idx_token_elim==None:
        selected_idx_pos = (torch.rand(idx_end_caption.shape[0], batch_size_GCD).to(idx_end_caption.device) * (idx_end_caption[:, None]-1).float()).floor().long() + 1
        new_possible_tokens = idx_max_per_pos.gather(1, selected_idx_pos.unsqueeze(2).expand(-1, -1, idx_max_per_pos.size(2)))
        l_rand_idx_token = (torch.rand(new_possible_tokens.shape[0], batch_size_GCD).to(idx_end_caption.device) * top_k_val).floor().long()
        selected_new_tokens = new_possible_tokens[torch.arange(new_possible_tokens.shape[0])[:, None], torch.arange(new_possible_tokens.shape[1])[None].to(idx_end_caption.device).long(), l_rand_idx_token]
    else:
        selected_idx_pos = idx_token_elim[:, None].repeat(1, top_k_val)
        selected_new_tokens = idx_max_per_pos[torch.arange(idx_end_caption.shape[0]).to(idx_end_caption.device), idx_token_elim]
    
    new_input_ids = input_ids[:,None,:].repeat(1, batch_size_GCD, 1)
    new_input_ids[torch.arange(new_input_ids.shape[0])[:, None], torch.arange(new_input_ids.shape[1])[None], selected_idx_pos] = selected_new_tokens

    new_attention_mask = attention_mask[:, None].repeat(1,batch_size_GCD,1)

    flatten_input_ids = new_input_ids.reshape(-1, new_input_ids.shape[-1])
    flatten_attention_mask = new_attention_mask.reshape(-1, new_input_ids.shape[-1])

    if alignment_metric == "BLIP":
        flatten_emb_img = emb_img[:, None].expand(-1, batch_size_GCD, -1, -1)
    else:
        flatten_emb_img = emb_img[:, None].expand(-1, batch_size_GCD, -1)
    return new_input_ids, flatten_input_ids, flatten_attention_mask, flatten_emb_img

def elimiation_embeddings(input_ids, idx_end_caption, attention_mask, emb_img, end_input_id):
    """
    Build elimination candidates by removing exactly one token from each position.

    For each sample i, we create (idx_end_caption[i]-1) candidates:
      - each candidate corresponds to deleting one token

    Returns flattened candidates plus an index vector (l_idx_id) that maps each
    candidate back to its original sample.
    """
    full_indices = torch.arange(input_ids.shape[1]).repeat(input_ids.shape[1], 1)
    mask = torch.ones(input_ids.shape[1], input_ids.shape[1], dtype=torch.bool)
    mask.fill_diagonal_(False)
    try:
        idx_to_keep_new_input_ids = full_indices[mask].reshape(input_ids.shape[1], input_ids.shape[1] - 1)[1:]
    except:
        import ipdb; ipdb.set_trace()
    new_input_ids = input_ids[:, idx_to_keep_new_input_ids]
    new_input_ids = torch.concat([new_input_ids[i, :idx_end_caption[i]-1] for i in range(new_input_ids.shape[0])])
    end_token_column = torch.ones((new_input_ids.shape[0], 1), dtype=new_input_ids.dtype, device=new_input_ids.device)*end_input_id
    new_input_ids = torch.cat((new_input_ids, end_token_column), dim=1)
    l_idx_id = []
    for i in range(len(idx_end_caption)):
        l_idx_id += [i]*(int(idx_end_caption[i])-1)
    l_idx_id = torch.Tensor(l_idx_id).int()
    if len(l_idx_id) != new_input_ids.shape[0]:
        import ipdb; ipdb.set_trace()

    flatten_input_ids = new_input_ids
    flatten_attention_mask = attention_mask[l_idx_id]
    flatten_emb_img = emb_img[l_idx_id]
    return l_idx_id, flatten_input_ids, flatten_attention_mask, flatten_emb_img

def find_max_batchsize(algorithm, flatten_emb_img, flatten_input_ids, flatten_attention_mask, max_batch_size_txt_model, test_pass_test, match_head):
    """
    Find a safe batch size for scoring text candidates without running out of GPU memory.

    This function repeatedly tries to run a forward pass with the current
    max_batch_size_txt_model. If it fails, it halves the batch size and tries 
    again until it succeeds.
    """
    torch.cuda.empty_cache()
    while not(test_pass_test):
        try:
            print("current max_batch_size_txt_model", max_batch_size_txt_model, flush=True)
            with torch.no_grad():
                if "BLIP" in algorithm.__str__()[:8]:
                    ind_start_sample = 0
                    ind_end_sample = (max_batch_size_txt_model)//flatten_emb_img.shape[0]
                    corres_emb_img = flatten_emb_img[:, ind_start_sample:ind_end_sample].reshape(-1, flatten_emb_img.shape[-2], flatten_emb_img.shape[-1])

                    init_score = algorithm.forward_after_tokenizer(corres_emb_img, flatten_input_ids[:max_batch_size_txt_model], flatten_attention_mask[:max_batch_size_txt_model], match_head=match_head)
                    if match_head == "itm":
                        init_score = torch.nn.functional.softmax(init_score,dim=1)[:,1]
                elif "VisionEncoderDecoderModel" in algorithm.__str__()[:25]:
                    corres_emb_img = BaseModelOutput(last_hidden_state=flatten_emb_img.last_hidden_state[:max_batch_size_txt_model].reshape(-1, flatten_emb_img.last_hidden_state.shape[-2], flatten_emb_img.last_hidden_state.shape[-1]))

                    outputs_tmp = algorithm(
                        decoder_input_ids=flatten_input_ids[:max_batch_size_txt_model],
                        encoder_outputs=corres_emb_img
                    )
                    init_score = torch.nn.functional.softmax(outputs_tmp['logits'][:, -1, [2334, 49922]])[:, 1].detach()
                else:
                    emb_txt_candidates = algorithm.encode_text(flatten_input_ids[:max_batch_size_txt_model], flatten_attention_mask[:max_batch_size_txt_model])
                    emb_txt_candidates = normalize_vectors(emb_txt_candidates)
            test_pass_test = True
            max_batch_size_txt_model = int(max_batch_size_txt_model/2)
        except Exception as e:
            print(e, flush=True)
            torch.cuda.empty_cache()
            max_batch_size_txt_model = int(max_batch_size_txt_model/2)
            if max_batch_size_txt_model == 0:
                import ipdb; ipdb.set_trace()
    return max_batch_size_txt_model, test_pass_test

def inject_fine_grained_noise(name_dataset, noise_level, seed, train_set, val_set, test_set, tokenizer, change_true=False):
    """
    Inject fine-grained caption noise by replacing a random subset of samples with precomputed "wrong" sentences.

    For each split (train/val/test):
      - Randomly select a fraction (noise_level) of indices to corrupt.
      - For each selected sample, retrieve a list of candidate wrong sentences and their NLI-based scores.
      - Keep the two "best" wrong candidates (lowest reg score) and randomly choose one to replace the caption.
      - Optionally (change_true=True), also modify the stored ground-truth sentence field.
    """
    np.random.seed(seed)
    with open(f'{path_datasets}/datasets/wrong_sentences_{name_dataset}/sentence_wrong_dict.pkl', 'rb') as handle:
        sentence_wrong_dict = pickle.load(handle)
    sentence_wrong_scores = torch.load(f'{path_datasets}/datasets/wrong_sentences_{name_dataset}/sentence_wrong_nli_scores_with_key.pt')
    
    idx_train_mislabel = np.random.choice(np.arange(len(train_set.df)), int(noise_level*len(train_set.df)), replace=False)
    idx_val_mislabel = np.random.choice(np.arange(len(val_set.df)), int(noise_level*len(val_set.df)), replace=False)
    idx_test_mislabel = np.random.choice(np.arange(len(test_set.df)), int(noise_level*len(test_set.df)), replace=False)

    tqdm.pandas()
    for dataset, idx_dataset in [(train_set, idx_train_mislabel), (val_set, idx_val_mislabel), (test_set, idx_test_mislabel)]:
        dataset.df = dataset.df.reset_index(drop=True)
        if "gold_sentence_copy" not in dataset.df:
            dataset.df["gold_sentence_copy"] = copy.deepcopy(dataset.df["gold_sentence"])
        for idx in tqdm(idx_dataset):
            wrong_sentences = sentence_wrong_dict[dataset.df["gold_sentence_copy"].iloc[idx]]
            scores_sentences = sentence_wrong_scores[dataset.df["gold_sentence_copy"].iloc[idx]]
            sorted_idx = torch.argsort(scores_sentences["reg"])
            kept_wrong_sentences = [wrong_sentences[sorted_idx[0]]]+[wrong_sentences[sorted_idx[1]]]
            try:
                dataset.df.loc[idx, "sentence"] = np.random.choice(kept_wrong_sentences, 1)[0]
            except:
                import ipdb; ipdb.set_trace()
            if change_true:
                dataset.df["gold_sentence"].iloc[idx] = np.random.choice(sentences_dict[dataset.df["gold_sentence_copy"].iloc[idx]], 1)[0]

def eval_new_alignment_scores(algorithm, flatten_emb_img, flatten_input_ids, max_batch_size_txt_model, flatten_attention_mask, is_GCD_data, device,
                        l_sample_idx, knn_k, index_img, index_txt, normalize_d1, train_indices_in_compr, batch_size, text_embeds_dataset_labels, emb_txt_tr, emb_img_tr, dist_type, use_discrete_for_text, tr_text_labels, dists_tr, beta, gamma, tau_1_n, tau_2_n, tau_1_m, tau_2_m, alignment_metric, match_head, force_disable_tqdm = False):
    """
    Score a set of candidate captions against their corresponding images.
    Returns a 1D tensor of scores, one per row in flatten_input_ids.
    """
    new_cosine_sim = torch.zeros(flatten_input_ids.shape[0]).to(device)

    with torch.no_grad():
        for ind_start in tqdm(range(0, len(flatten_input_ids), max_batch_size_txt_model), disable=not(is_GCD_data) or force_disable_tqdm):
            test_shapes = flatten_emb_img.shape[0]!=flatten_input_ids.shape[0]

            if test_shapes:
                shape_flatten_emb_img = flatten_emb_img.shape[1]
                ind_start_sample = ind_start//shape_flatten_emb_img
                ind_end_sample = (ind_start+max_batch_size_txt_model)//shape_flatten_emb_img
                if "BLIP" in algorithm.__str__()[:8]:
                    corres_emb_img = flatten_emb_img[ind_start_sample:ind_end_sample, :].reshape(-1, flatten_emb_img.shape[-2], flatten_emb_img.shape[-1])
                else:
                    corres_emb_img = flatten_emb_img[ind_start_sample:ind_end_sample, :].reshape(-1, flatten_emb_img.shape[-1])
            else:
                corres_emb_img = flatten_emb_img[ind_start:ind_start+max_batch_size_txt_model]

            if "BLIP" in algorithm.__str__()[:8]:
                itm_output = algorithm.forward_after_tokenizer(corres_emb_img, flatten_input_ids[ind_start:ind_start+max_batch_size_txt_model], flatten_attention_mask[ind_start:ind_start+max_batch_size_txt_model], match_head=match_head)
                if match_head == "itm":
                    new_cosine_sim[ind_start:ind_start+max_batch_size_txt_model] = torch.nn.functional.softmax(itm_output,dim=1)[:,1]
                else:
                    new_cosine_sim[ind_start:ind_start+max_batch_size_txt_model] = itm_output
            elif "VisionEncoderDecoderModel" in algorithm.__str__()[:25]:
                size_sub_batch = max_batch_size_txt_model//32
                for ind_step in range(ind_start, min(ind_start+max_batch_size_txt_model, flatten_input_ids.shape[0]), size_sub_batch):
                    outputs = algorithm(
                    decoder_input_ids=flatten_input_ids[ind_step:ind_step+size_sub_batch],
                    encoder_outputs=BaseModelOutput(last_hidden_state=corres_emb_img.last_hidden_state[ind_step:ind_step+size_sub_batch])
                    )
                    new_cosine_sim[ind_step:ind_step+size_sub_batch] = torch.nn.functional.softmax(outputs['logits'][:, -1, [2334, 49922]])[:, 1].detach()
            else:
                emb_txt_candidates = algorithm.encode_text(flatten_input_ids[ind_start:ind_start+max_batch_size_txt_model], flatten_attention_mask[ind_start:ind_start+max_batch_size_txt_model])
                emb_txt_candidates = normalize_vectors(emb_txt_candidates)

                if "LEMON" in alignment_metric:
                    new_cosine_sim[ind_start:ind_start+max_batch_size_txt_model] = compute_lemon_score(l_sample_idx[ind_start:ind_start+max_batch_size_txt_model].to(device), corres_emb_img, emb_txt_candidates, knn_k, index_img, index_txt, normalize_d1, train_indices_in_compr, batch_size, text_embeds_dataset_labels, emb_txt_tr, emb_img_tr, dist_type, use_discrete_for_text, tr_text_labels, dists_tr, beta, gamma, tau_1_n, tau_2_n, tau_1_m, tau_2_m, device)
                else:
                    try:
                        new_cosine_sim[ind_start:ind_start+max_batch_size_txt_model] = emb_txt_candidates[:,None,:].bmm(corres_emb_img[:, :, None])[:, 0, 0]
                    except:
                        import ipdb; ipdb.set_trace()

    return new_cosine_sim

def best_elim_step(new_cosine_sim, l_idx_id, input_ids, idx_end_caption, flatten_input_ids, mat_alignment_scores, n_seen, size_batch, iter_GCD, device):
    """
    Select the best elimination candidate for each original sample.
    Returns:
      - updated_input_ids: chosen best candidate per sample (or original if caption is already empty)
      - best_cos_sim: best score per sample (or previous score if caption is already empty)
    """
    all_cosines = torch.concat([new_cosine_sim[None], l_idx_id[None].to(device)]).T
    max_values = torch.full_like(torch.arange(input_ids.shape[0]).float(), -float('inf')).to(device)
    max_indices = torch.full_like(torch.arange(input_ids.shape[0]), -1, dtype=torch.long).to(device)
    max_values.scatter_reduce_(dim=0, index=all_cosines[:, 1].long(), src=all_cosines[:, 0], reduce="amax")
    mask = (all_cosines[:, 0] == max_values[all_cosines[:, 1].long()])
    masked_indices = torch.arange(all_cosines.shape[0]).to(all_cosines.device) * mask
    max_indices.scatter_reduce_(dim=0, index=all_cosines[:, 1].long(), src=masked_indices, reduce="amax")
    updated_input_ids = torch.zeros_like(input_ids)
    updated_input_ids[idx_end_caption>1] = flatten_input_ids[max_indices[idx_end_caption>1]]
    updated_input_ids[idx_end_caption<=1] = input_ids[idx_end_caption<=1]
    best_cos_sim = max_values
    best_cos_sim[idx_end_caption<=1] = mat_alignment_scores[n_seen:n_seen+size_batch, iter_GCD][idx_end_caption<=1]
    return updated_input_ids, best_cos_sim

def compute_lemon_score(l_sample_idx, img_embeds, text_embeds, knn_k, index_img, index_txt, normalize_d1, train_indices_in_compr, batch_size, text_embeds_dataset_labels, emb_txt_tr, emb_img_tr, dist_type, use_discrete_for_text, tr_text_labels, dists_tr, beta, gamma, tau_1_n, tau_2_n, tau_1_m, tau_2_m, device):
    """
    Compute the LEMON alignment score for each (image, text) pair in the dataset.
    """
    emb_img_tr = emb_img_tr.to(device)
    emb_txt_tr = emb_txt_tr.to(device)
    dists_tr = dists_tr.to(device)
    if img_embeds.device != emb_img_tr.device:
        img_embeds = img_embeds.to(device)
    if text_embeds.device != emb_txt_tr.device:
        text_embeds = text_embeds.to(device)

    if dist_type == "cosine":
        all_cos_sim_img = img_embeds @ emb_img_tr.T
        D_ns, I_ns = torch.topk(all_cos_sim_img, k=knn_k+1, dim=1)

        all_cos_sim_text = text_embeds @ emb_txt_tr.T
        D_ms, I_ms = torch.topk(all_cos_sim_text, k=knn_k+1, dim=1)
    
    elif dist_type == 'euclidean':
        img_norm_sq = (img_embeds ** 2).sum(dim=1, keepdim=True)
        emb_img_tr_norm_sq = (emb_img_tr ** 2).sum(dim=1).unsqueeze(0)
        dists = img_norm_sq + emb_img_tr_norm_sq - 2 * (img_embeds @ emb_img_tr.T)
        D_ns, I_ns = torch.topk(dists, k=knn_k+1, dim=1, largest=False)

        text_norm_sq = (text_embeds ** 2).sum(dim=1, keepdim=True)
        emb_txt_tr_norm_sq = (emb_txt_tr ** 2).sum(dim=1).unsqueeze(0)
        dists = text_norm_sq + emb_txt_tr_norm_sq - 2 * (text_embeds @ emb_txt_tr.T)
        D_ms, I_ms = torch.topk(dists, k=knn_k+1, dim=1, largest=False)

    if normalize_d1:
        print("Not implemented yet")
        import ipdb; ipdb.set_trace()
        if dist_type == 'cosine':
            d1 = softmax(1 - (img_embeds * text_embeds_dataset_labels).sum(axis = 1))[noisy_labels[i]]
        elif dist_type == 'euclidean':
            d1 = softmax(((img_embeds.flatten() - text_embeds_dataset_labels)**2).sum(axis = 1))[noisy_labels[i]]
    else:
        if dist_type == 'cosine':
            d1 = 1 - torch.bmm(img_embeds[:, None], text_embeds[:, :, None])[:, 0, 0]
        elif dist_type == 'euclidean':
            d1 = ((img_embeds - text_embeds)**2).sum(1)

    l_sample_is_train = torch.isin(l_sample_idx, train_indices_in_compr).to(device)
    l_sample_is_not_train = ~l_sample_is_train 

    new_I_ns = torch.zeros(I_ns.shape).to(device).long()[:, :-1]
    new_I_ns[l_sample_is_train] = I_ns[l_sample_is_train, 1:]
    new_I_ns[l_sample_is_not_train] = I_ns[l_sample_is_not_train, :-1]

    new_I_ms = torch.zeros(I_ms.shape).to(device).long()[:, :-1]
    new_I_ms[l_sample_is_train] = I_ms[l_sample_is_train, 1:]
    new_I_ms[l_sample_is_not_train] = I_ms[l_sample_is_not_train, :-1]

    new_D_ns = torch.zeros(D_ns.shape).to(device)[:, :-1]
    new_D_ns[l_sample_is_train] = D_ns[l_sample_is_train, 1:]
    new_D_ns[l_sample_is_not_train] = D_ns[l_sample_is_not_train, :-1]

    new_D_ms = torch.zeros(D_ms.shape).to(device)[:, :-1]
    new_D_ms[l_sample_is_train] = D_ms[l_sample_is_train, 1:]
    new_D_ms[l_sample_is_not_train] = D_ms[l_sample_is_not_train, :-1]

    y_n = emb_txt_tr.to(device)[new_I_ns]
    x_m = emb_img_tr.to(device)[new_I_ms]

    if use_discrete_for_text:
        dists_n = 1 - torch.Tensor(tr_text_labels[new_I_ns.cpu().numpy()] == np.array(noisy_text_labels_prompts)[:, None]).float()
    else:
        if dist_type == 'cosine':
            new_D_ns = -new_D_ns
            dists_n = 1 - (text_embeds[:, None] * y_n).sum(axis = 2)
        elif dist_type == 'euclidean':
            dists_n = ((text_embeds[:, None] - y_n)**2).sum(axis = 2)

    if dist_type == 'cosine':
        new_D_ms = -new_D_ms
        dists_m = 1 - (img_embeds[:, None] * x_m).sum(axis = 2)
    elif dist_type == 'euclidean':
        dists_m = ((img_embeds[:, None] - x_m)**2).sum(axis = 2)

    score_n = (dists_n*torch.exp(-tau_1_n*new_D_ns-tau_2_n*dists_tr[new_I_ns])).mean(1)
    score_m = (dists_m*torch.exp(-tau_1_m*new_D_ms-tau_2_m*dists_tr[new_I_ms])).mean(1)
    score = d1 + beta*score_n + gamma*score_m

    return -score

@torch.no_grad()
def compute_text_embeddings(captions, device, algorithm, alignment_metric, tokenizer, batch_size, disable_tqdm=False):
    """
    Compute normalized text embeddings for a list of captions.
    """
    algorithm.to(device)

    if "BLIP" in algorithm.__str__()[:8]:
        emb_dim = int(algorithm.vision_proj.__str__().split(", ")[1].split("=")[1])
    else:
        emb_dim = int(algorithm.text_model.final_layer_norm.__str__().split("(")[2].split(",)")[0])

    emb_txt = torch.zeros((len(captions), emb_dim), device = device)

    for i in tqdm(range(0, len(captions), batch_size), disable=disable_tqdm):
        encodings, input_ids, attention_mask = get_encoding_batch(alignment_metric, captions[i:(i+batch_size)], tokenizer, device)
        _, emb_txt_batch = get_CLIP_embeddings_batch(alignment_metric, algorithm, None, encodings, input_ids, attention_mask, True, False)
        emb_txt[i:(i+batch_size)] = emb_txt_batch

    return emb_txt

def get_name_exp(exploration_strat, save_folder, output_dir, dataset, top_k_val, num_steps_GCD, noise_type, noise_level, alignment_metric, batch_size_GCD, seed, match_head, obj_direction):
    """
    Build a unique experiment output directory name from the run configuration.
    """
    if exploration_strat == 2:
        batch_size_GCD = top_k_val

    path_start = save_folder+"saved_exp/"+output_dir+f"_{dataset}_{int(noise_level*100)}"
    if exploration_strat == 0:
        out_dir = path_start+f"_TRACED_elim"
    elif exploration_strat == 1:
        out_dir = path_start+f"_TRACED_CGD_{top_k_val}_{batch_size_GCD}_{num_steps_GCD}"
    elif exploration_strat == 2:
        out_dir = path_start+f"_TRACED_FCGD_{top_k_val}_{num_steps_GCD}"

    if noise_type != "noun":
        out_dir += f"_{noise_type}"

    out_dir += "_"+alignment_metric

    if "BLIP" in alignment_metric:
        out_dir += f"_{match_head}"
    
    if obj_direction=="min":
        out_dir += f"_min"
        
    if seed!=0:
        out_dir += "_s"+str(seed)

    return out_dir

def read_batch(batch, name_dataset, device):
    """
    Unpack a dataloader batch.

    Returns:
      size_batch: number of samples in the batch
      pixel_values: image tensors
      noisy_text_labels: noisy captions
      true_text_labels: true captions
    """
    size_batch = len(batch[1])
    pixel_values = batch[0].to(device)

    noisy_text_labels = batch[2]
    true_text_labels = batch[1]

    return size_batch, pixel_values, noisy_text_labels, true_text_labels

def get_encoding_batch(alignment_metric, text_labels, tokenizer, device):
    """
    Tokenize a batch of captions into model inputs.
    Returns:
      encodings: tokenizer outputs
      input_ids: token IDs
      attention_mask: attention mask
    """
    if alignment_metric=="BLIP":
        encodings = tokenizer(text_labels, padding='max_length', truncation=True, max_length=35, 
                              return_tensors="pt").to(device)
        input_ids = torch.tensor(encodings["input_ids"]).to(device)
        attention_mask = torch.tensor(encodings["attention_mask"]).to(device)
    else:
        encodings = tokenizer(
                text_labels, padding="max_length", truncation=True)
        input_ids = torch.tensor(encodings["input_ids"]).to(device)
        attention_mask = torch.tensor(encodings["attention_mask"]).to(device)

    return encodings, input_ids, attention_mask

def get_CLIP_embeddings_batch(alignment_metric, algorithm, pixel_values, encodings, input_ids, attention_mask, test_compute_text_emb, test_compute_img_emb):
    """
    Compute normalized image and/or text embeddings for a single batch.

    Behavior:
      - If test_compute_img_emb is True, encode images.
      - If test_compute_text_emb is True, encode captions.

    Returns:
      emb_img: normalized image embeddings (or None if not computed)
      emb_txt: normalized text embeddings (or None if not computed)
    """
    emb_img, emb_txt = None, None
    if test_compute_img_emb:
        emb_img = algorithm.encode_image(pixel_values)
        emb_img = normalize_vectors(emb_img)
    else:
        emb_img = None
                
    if test_compute_text_emb:
        if alignment_metric == 'BLIP':
            emb_txt = algorithm.text_proj(algorithm.text_encoder(input_ids, attention_mask = attention_mask, return_dict = True, mode = 'text').last_hidden_state[:,0,:])
        else:
            emb_txt = algorithm.encode_text(input_ids, attention_mask)
        emb_txt = normalize_vectors(emb_txt)

    return emb_img, emb_txt

def freeze_CLIP_except_emb(algorithm):
    """
    Freeze all model parameters except the text embedding layer.
    """
    for param in algorithm.parameters():
        param.requires_grad = False
    try:
        for param in algorithm.text_model.embeddings.parameters():
            param.requires_grad = True
    except:
        try:
            for param in algorithm.text_encoder.embeddings.parameters():
                param.requires_grad = True
        except:
            for param in algorithm.decoder.model.decoder.embed_tokens.parameters():
                param.requires_grad = True

def algorithm_step(exploration_strat, idx, algorithm, encodings, input_ids, attention_mask, emb_img, end_input_id, start_input_id, top_k_val, idx_end_caption, batch_size_GCD, mat_alignment_scores, n_seen, size_batch, iter_GCD, device, max_batch_size_txt_model, test_pass_test, 
                knn_k, index_img, index_txt, normalize_d1, train_indices_in_compr, batch_size, text_embeds_dataset_labels, emb_txt_tr, emb_img_tr, dist_type, use_discrete_for_text, tr_text_labels, dists_tr, beta, gamma, tau_1_n, tau_2_n, tau_1_m, tau_2_m, alignment_metric, match_head, obj_direction,
                force_disable_tqdm = False, test_debug=False):
    """
    Perform one TRACED step for a batch (one iteration of Elim / GCD / FGCD).

    Returns:
      best_cos_sim: best score achieved for each sample at this step
      max_batch_size_txt_model: updated safe batch size for scoring
      test_pass_test: whether the batch-size probe has succeeded
      input_ids: updated token ids after applying the best edit per sample
    """
    if exploration_strat == 0:
        l_idx_id, flatten_input_ids, flatten_attention_mask, flatten_emb_img = elimiation_embeddings(input_ids, idx_end_caption, attention_mask, emb_img, end_input_id)
        l_sample_idx = l_idx_id+idx*batch_size
    elif exploration_strat == 1:
        l_sample_idx = idx * batch_size + torch.arange(emb_img.shape[0], device = device)
        torch.cuda.empty_cache()
        new_input_ids, flatten_input_ids, flatten_attention_mask, flatten_emb_img = GCD_embedings(alignment_metric, algorithm, encodings, input_ids, attention_mask, emb_img, end_input_id, start_input_id, top_k_val, idx_end_caption, batch_size_GCD, None, 
                        l_sample_idx, knn_k, index_img, index_txt, normalize_d1, train_indices_in_compr, batch_size, text_embeds_dataset_labels, emb_txt_tr, emb_img_tr, dist_type, use_discrete_for_text, tr_text_labels, dists_tr, beta, gamma, tau_1_n, tau_2_n, tau_1_m, tau_2_m, alignment_metric, match_head, obj_direction, test_debug)
        l_sample_idx = (idx * batch_size + torch.arange(emb_img.shape[0], device = device)[:, None].repeat(1, new_input_ids.shape[1])).flatten()
    elif exploration_strat == 2:
        l_idx_id, flatten_input_ids, flatten_attention_mask, flatten_emb_img = elimiation_embeddings(input_ids, idx_end_caption, attention_mask, emb_img, end_input_id)
        l_sample_idx = (l_idx_id+idx*batch_size).to(device)
        torch.cuda.empty_cache()
        max_batch_size_txt_model, _ = find_max_batchsize(algorithm, flatten_emb_img, flatten_input_ids, flatten_attention_mask, max_batch_size_txt_model, test_pass_test, match_head)
        new_cosine_sim = eval_new_alignment_scores(algorithm, flatten_emb_img, flatten_input_ids, max_batch_size_txt_model, flatten_attention_mask, False, device,
            l_sample_idx, knn_k, index_img, index_txt, normalize_d1, train_indices_in_compr, batch_size, text_embeds_dataset_labels, emb_txt_tr, emb_img_tr, dist_type, use_discrete_for_text, tr_text_labels, dists_tr, beta, gamma, tau_1_n, tau_2_n, tau_1_m, tau_2_m, alignment_metric, match_head,
            force_disable_tqdm=force_disable_tqdm)
        best_input_ids, best_cos_sim = best_elim_step(new_cosine_sim, l_idx_id, input_ids, idx_end_caption, flatten_input_ids, mat_alignment_scores, n_seen, size_batch, iter_GCD, device)
        idx_token_elim = (best_input_ids - input_ids != 0).max(dim=1).indices
        del l_idx_id, flatten_input_ids, flatten_attention_mask, flatten_emb_img, new_cosine_sim, best_input_ids, best_cos_sim
        torch.cuda.empty_cache()
        l_sample_idx = idx * batch_size + torch.arange(emb_img.shape[0], device = device)
        new_input_ids, flatten_input_ids, flatten_attention_mask, flatten_emb_img = GCD_embedings(alignment_metric, algorithm, encodings, input_ids, attention_mask, emb_img, end_input_id, start_input_id, top_k_val, idx_end_caption, batch_size_GCD, idx_token_elim,
                                                                                l_sample_idx, knn_k, index_img, index_txt, normalize_d1, train_indices_in_compr, batch_size, text_embeds_dataset_labels, emb_txt_tr, emb_img_tr, dist_type, use_discrete_for_text, tr_text_labels, dists_tr, beta, gamma, tau_1_n, tau_2_n, tau_1_m, tau_2_m, alignment_metric, match_head, obj_direction)
        l_sample_idx = (idx * batch_size + torch.arange(emb_img.shape[0], device = device)[:, None].repeat(1, new_input_ids.shape[1])).flatten()

    torch.cuda.empty_cache()

    max_batch_size_txt_model, test_pass_test = find_max_batchsize(algorithm, flatten_emb_img, flatten_input_ids, flatten_attention_mask, max_batch_size_txt_model, test_pass_test, match_head)

    torch.cuda.empty_cache()
    new_cosine_sim = eval_new_alignment_scores(algorithm, flatten_emb_img, flatten_input_ids, max_batch_size_txt_model, flatten_attention_mask, exploration_strat == 1, device,
            l_sample_idx, knn_k, index_img, index_txt, normalize_d1, train_indices_in_compr, batch_size, text_embeds_dataset_labels, emb_txt_tr, emb_img_tr, dist_type, use_discrete_for_text, tr_text_labels, dists_tr, beta, gamma, tau_1_n, tau_2_n, tau_1_m, tau_2_m, alignment_metric, match_head,
            force_disable_tqdm=force_disable_tqdm)
    del flatten_emb_img
    torch.cuda.empty_cache()

    if obj_direction=="min":
        new_cosine_sim *= -1

    if exploration_strat in [1,2]:
        new_cosine_sim = new_cosine_sim.reshape(new_input_ids.shape[0], new_input_ids.shape[1])
        best_cos_sim, idx_best_cos_sim = torch.max(new_cosine_sim, 1)
        input_ids = new_input_ids[torch.arange(input_ids.shape[0], device=idx_best_cos_sim.device), idx_best_cos_sim]
    else:
        best_input_ids, best_cos_sim = best_elim_step(new_cosine_sim, l_idx_id, input_ids, idx_end_caption, flatten_input_ids, mat_alignment_scores, n_seen, size_batch, iter_GCD, device)
        idx_end_caption[idx_end_caption>1] -= 1
        input_ids = best_input_ids

    if obj_direction=="min":
        best_cos_sim *= -1

    return best_cos_sim, max_batch_size_txt_model, test_pass_test, input_ids

def perform_alg(dataset, device, algorithm, args, exploration_strat, batch_size_GCD, hparams, num_steps_GCD, start_input_id, top_k_val, name_dataset, tokenizer, end_input_id, index_img, index_txt, train_indices_in_compr, text_embeds_dataset_labels, emb_txt_tr, emb_img_tr, tr_text_labels, dists_tr, beta, gamma, tau_1_n, tau_2_n, tau_1_m, tau_2_m, match_head, obj_direction, test_debug=False):
    """
    Run the TRACED algorithm on a dataset and collect trajectory outputs.

    1) Tokenize the current captions and compute the initial alignment score (step 0).
    2) For each TRACED step (iter_GCD = 0..num_steps_GCD-1):
        - call algorithm_step(...) to generate candidates and pick the best edit
        - record the new scores and the updated caption
        - record which token was changed/removed (d_word_change)
    3) Store results for the entire dataset:
        - mat_alignment_scores: [N, num_steps_GCD+1] alignment score trajectory
        - d_new_sentences: dict with per-step decoded captions + original noisy/true captions
        - d_word_change: dict with per-step token that changed

    Returns:
      mat_alignment_scores (CPU), d_new_sentences, d_word_change
    """
    tokenizer = load_tokenizer("BLIP" if args.alignment_metric == "BLIP" else "huggingface_clip")
    dataloader = DataLoader(dataset=dataset, batch_size=hparams["batch_size"])#, num_workers=4)
    algorithm.to(device)
    freeze_CLIP_except_emb(algorithm)

    max_batch_size_txt_model = batch_size_GCD*hparams["batch_size"]
    test_pass_test = False
    if args.alignment_metric == "BLIP":
        max_batch_size_txt_model = 2048
        test_pass_test = True
    elif args.alignment_metric == "CLIP":
        max_batch_size_txt_model = int(2*2048)
        test_pass_test = True
    n_seen = 0
    
    mat_alignment_scores = torch.zeros((len(dataloader.dataset), num_steps_GCD+1)).to(device)
    print(len(dataloader.dataset))
    d_new_sentences = {}
    d_word_change = {}
    
    for iter_GCD in range(num_steps_GCD):
        d_new_sentences[iter_GCD] = []
        d_word_change[iter_GCD] = []

    d_new_sentences["noisy"] = []
    d_new_sentences["true"] = []
    
    start_time_perform_alg = time.time()
    print("Start Time", flush=True)
    for idx, batch in tqdm(enumerate(dataloader), total = len(dataloader)):
        size_batch, pixel_values, text_labels, _ = read_batch(batch, name_dataset, device)
        
        d_new_sentences["noisy"] += batch[2]
        d_new_sentences["true"] += batch[1]

        encodings, input_ids, attention_mask = get_encoding_batch(args.alignment_metric, text_labels, tokenizer, device)
        if type(encodings['attention_mask']) == list:
            encodings['attention_mask'] = np.array(encodings['attention_mask'])

        idx_end_caption = torch.Tensor(encodings['attention_mask'].sum(1)).to(device).long()

        if args.alignment_metric == "BLIP":
            with torch.no_grad():
                emb_img = algorithm.visual_encoder(pixel_values)
                init_score = algorithm.forward_after_tokenizer(emb_img, input_ids, attention_mask, match_head=match_head)
                if match_head == "itm":
                    init_score = torch.nn.functional.softmax(init_score,dim=1)[:,1]
        else:
            emb_img, emb_txt = get_CLIP_embeddings_batch(args.alignment_metric, algorithm, pixel_values, encodings, input_ids, attention_mask, True, True)
            with torch.no_grad():
                if "LEMON" in args.alignment_metric:
                    l_sample_idx = idx * args.batch_size + torch.arange(emb_img.shape[0], device = device)
                    train_indices_in_compr = train_indices_in_compr.to(device)
                    init_score = compute_lemon_score(l_sample_idx, emb_img, emb_txt, args.knn_k, index_img, index_txt, args.normalize_d1, train_indices_in_compr, args.batch_size, text_embeds_dataset_labels, emb_txt_tr, emb_img_tr, args.dist_type, args.use_discrete_for_text, tr_text_labels, dists_tr, beta, gamma, tau_1_n, tau_2_n, tau_1_m, tau_2_m, device)
                else:
                    init_score = (emb_txt[:,None,:].bmm(emb_img[:, :, None])[:, 0, 0]).detach()

        mat_alignment_scores[n_seen:n_seen+size_batch, 0] = init_score

        for iter_GCD in tqdm(range(num_steps_GCD)):
            old_input_ids = copy.deepcopy(input_ids)
            best_cos_sim, max_batch_size_txt_model, test_pass_test, input_ids = algorithm_step(exploration_strat, idx, algorithm, encodings, input_ids, attention_mask, emb_img, end_input_id, start_input_id, top_k_val, idx_end_caption, batch_size_GCD, mat_alignment_scores, n_seen, size_batch, iter_GCD, device, max_batch_size_txt_model, test_pass_test,
                                                                                    args.knn_k, index_img, index_txt, args.normalize_d1, train_indices_in_compr, args.batch_size, text_embeds_dataset_labels, emb_txt_tr, emb_img_tr, args.dist_type, args.use_discrete_for_text, tr_text_labels, dists_tr, beta, gamma, tau_1_n, tau_2_n, tau_1_m, tau_2_m, args.alignment_metric, match_head, obj_direction, test_debug=test_debug)

            idx_eliminated_tokens = torch.where(old_input_ids - input_ids!=0)
            idx_eliminated_tokens_0 = idx_eliminated_tokens[0]
            idx_eliminated_tokens_1 = idx_eliminated_tokens[1]
            eliminated_tokens_ids = torch.zeros(input_ids.shape[0], dtype = input_ids.dtype, device = input_ids.device)
            if len(idx_eliminated_tokens_0)>0:
                idx_to_add_0 = idx_eliminated_tokens_0[[0]]
                idx_to_add_1 = idx_eliminated_tokens_1[[0]]
                idx_eliminated_sentences = idx_eliminated_tokens_0[torch.where(idx_eliminated_tokens_0[1:] - idx_eliminated_tokens_0[:-1]==1)[0]+1]
                idx_eliminated_sentences = torch.cat([idx_to_add_0, idx_eliminated_sentences])
                idx_eliminated_tokens = idx_eliminated_tokens_1[torch.where(idx_eliminated_tokens_0[1:] - idx_eliminated_tokens_0[:-1]==1)[0]+1]
                idx_eliminated_tokens = torch.cat([idx_to_add_1, idx_eliminated_tokens])
                eliminated_tokens_ids[idx_eliminated_sentences] = old_input_ids[idx_eliminated_sentences, idx_eliminated_tokens]
            d_word_change[iter_GCD] += [tokenizer.decode(eliminated_tokens_ids[i], skip_special_tokens=True) for i in range(len(input_ids))]
            mat_alignment_scores[n_seen:n_seen+size_batch, iter_GCD+1] = best_cos_sim
            d_new_sentences[iter_GCD] += [tokenizer.decode(input_ids[i], skip_special_tokens=True).replace('<chartqa> Does the image entails this statement: "', '').replace('"? <s_answer>', '') for i in range(len(input_ids))]
        n_seen += size_batch
    print("End Time Perform Alg", time.time() - start_time_perform_alg, flush=True)
    return mat_alignment_scores.to("cpu"), d_new_sentences, d_word_change

def split_dataset(dataset, n_parts):
    """
    Split a dataset into n_parts roughly equally.
    Returns a list of Subset datasets.
    """
    dataset_size = len(dataset)
    indices = list(range(dataset_size))
    splits = []
    split_sizes = [(dataset_size + i) // n_parts for i in range(n_parts)]

    start_idx = 0
    for size in split_sizes:
        end_idx = start_idx + size
        splits.append(Subset(dataset, indices[start_idx:end_idx]))
        start_idx = end_idx

    return splits

def gpu_fn(rank, subdataset, d_res, d_completed, fn, device, *args, **kwargs):
    """
    Worker entry point for a spawned process.

    Runs fn(subdataset, device, ...) and writes:
      - the returned result into the shared dict d_res[rank]
      - a completion flag into d_completed[rank]
    """
    out = fn(subdataset, device, *args, **kwargs)
    d_res[rank] = out
    d_completed[rank] = 1

def run_multi_gpu(fn, data, n_gpus, n_jobs_per_gpu, *args, **kwargs):
    """
    Run a function in parallel across multiple GPUs by spawning processes.
    
    Behavior:
      - If n_gpus > 1:
          * Split data into n_gpus * n_jobs_per_gpu subdatasets
          * Spawn one process per job (rank), assign it to a GPU device
          * Collect results in rank order
      - If n_gpus == 1:
          * Run directly on a single device (cuda:0 if available, else cpu)

    Returns:
      results: list of outputs, one per rank.
    """
    if n_gpus > 1:
        mp.set_start_method('spawn', force=True)
        manager = mp.Manager()
        d_res = manager.dict()
        d_completed = manager.dict()
        n_scripts = int(n_gpus*n_jobs_per_gpu)
        subdatasets = split_dataset(data, n_scripts)

        processes = []

        for rank in range(n_scripts):
            device_id = int(rank//n_jobs_per_gpu)
            device = f"cuda:{device_id}"
            d_completed[rank] = 0

            p = mp.Process(target=gpu_fn, args=(rank, subdatasets[rank], d_res, d_completed, fn, device, *args), kwargs=kwargs)
            print(f"Rank {rank} starting on {device}", flush=True)
            p.start()
            processes.append(p)

        for p in processes:
            p.join()

        for rank in range(n_scripts):
            assert d_completed[rank] == 1, f"GPU {rank} failed"

        results = [d_res[rank] for rank in range(n_scripts)]

    else:
        device = f"cuda:{0}" if torch.cuda.is_available() else "cpu"
        start_time_mutli = time.time()
        print("Start Time single_GPU:", flush=True)
        results = [fn(data, device, *args, **kwargs)]
        end_time = time.time()
        print("")
        print("Time single_GPU:", end_time-start_time_mutli, flush=True)
        print("")

    return results

def run_multi_gpu_list(fn, d_data, n_gpus, n_jobs_per_gpu, *args, **kwargs):
    """
    Run a function in parallel across multiple GPUs by spawning processes.

    Behavior:
      - If n_gpus > 1:
          * Split each list in d_data into per-GPU chunks
          * Spawn one process per rank and run fn on the corresponding dict chunk
          * Collect results in rank order
      - If n_gpus == 1:
          * Run directly on a single device

    Returns:
      results: list of outputs, one per rank/job.
    """
    if n_gpus > 1:
        mp.set_start_method('spawn', force=True)
        manager = mp.Manager()
        d_res = manager.dict()
        d_completed = manager.dict()
        n_scripts = int(n_gpus*n_jobs_per_gpu)
        n_samples_per_gpu = int(np.ceil(len(d_data["true"])/n_gpus))
        subdatasets = []
        for i in range(n_gpus):
            d_subset = {}
            for key in d_data:
                d_subset[key] = d_data[key][i*n_samples_per_gpu: (i+1)*n_samples_per_gpu]
            subdatasets.append(d_subset)

        processes = []

        for rank in range(n_scripts):
            device_id = int(rank//n_jobs_per_gpu)
            device = f"cuda:{device_id}"
            d_completed[rank] = 0
            p = mp.Process(target=gpu_fn, args=(rank, subdatasets[rank], d_res, d_completed, fn, device, *args), kwargs=kwargs)
            p.start()
            processes.append(p)

        for p in processes:
            p.join()

        for rank in range(n_scripts):
            assert d_completed[rank] == 1, f"GPU {rank} failed"

        results = [d_res[rank] for rank in range(n_scripts)]
    else:
        device = f"cuda:{0}" if torch.cuda.is_available() else "cpu"
        results = [fn(d_data, device, *args, **kwargs)]

    return results

def perform_add_score(d_sentences, device, args, algorithm, tokenizer, copy_algorithm):
    """
    Compute per-step alignment scores between the initial noisy caption embeddings and
    the embeddings of the edited captions produced the TRACED trajectory.

    Returns:
      d_cos_sim_sentences: dict[step] -> tensor [N] of cosine similarities
    """
    d_cos_sim_sentences = {}

    emb_init_sentences = compute_text_embeddings(d_sentences["noisy"], device, algorithm, args.alignment_metric, tokenizer, 128)

    for i in tqdm(range(len(d_sentences)-2)):
        if i >= 1:
            l_test_remaining = np.array(d_sentences[i-1])!=np.array(d_sentences[i])
            l_test_same = np.array(d_sentences[i-1])==np.array(d_sentences[i])
        else:
            l_test_remaining = np.ones(len(d_sentences[i]), dtype = bool)
            l_test_same = np.zeros(len(d_sentences[i]), dtype = bool)
        l_test_remaining = torch.Tensor(l_test_remaining).bool().to(device)
        l_test_same = torch.Tensor(l_test_same).bool().to(device)
        remaining_sentences = [d_sentences[i][ind_caption] for ind_caption in range(len(d_sentences[i])) if l_test_remaining[ind_caption]]
        emb_current_sentence = compute_text_embeddings(remaining_sentences, device, algorithm, args.alignment_metric, tokenizer, 128)
        d_cos_sim_sentences[i] = torch.zeros(len(d_sentences[i]), device=device)
        d_cos_sim_sentences[i][l_test_remaining] = emb_init_sentences[l_test_remaining, None].matmul(emb_current_sentence[:,:,None])[:, 0,0]
        if l_test_same.sum()>0:
            d_cos_sim_sentences[i][l_test_same] = d_cos_sim_sentences[i-1][l_test_same]
    
    for key in d_cos_sim_sentences:
        try:
            d_cos_sim_sentences[key] = d_cos_sim_sentences[key].to("cpu")
        except:
            pass
    return d_cos_sim_sentences
