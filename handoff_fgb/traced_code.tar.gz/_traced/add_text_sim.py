from create_trajectory import *
from utils_TRACED import run_multi_gpu_list, perform_add_score

os.environ["TOKENIZERS_PARALLELISM"] = "false"

if __name__ == "__main__":
    args = parser.parse_args()
    n_gpus = torch.cuda.device_count()

    hparams = vars(args)

    top_k_val = hparams['top_k_val']
    batch_size_GCD = hparams['batch_size_GCD']
    num_steps_GCD = hparams['num_steps_GCD']
    exploration_strat = hparams['exploration_strat']

    print("Environment:")
    print("\tPython: {}".format(sys.version.split(" ")[0]))
    print("\tPyTorch: {}".format(torch.__version__))
    print("\tCUDA: {}".format(torch.version.cuda))
    print("\tCUDNN: {}".format(torch.backends.cudnn.version()))
    print("\tNumPy: {}".format(np.__version__))
    print("\tNode: {}".format(socket.gethostname()))

    print('Args:')
    for k, v in sorted(hparams.items()):
        print('\t{}: {}'.format(k, v))

    # Set seeds
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
        
    save_folder = f"{path_save_folder}/"

    out_dir = get_name_exp(exploration_strat, save_folder, args.output_dir, args.dataset, top_k_val, num_steps_GCD, args.noise_type, args.noise_level, args.alignment_metric, args.batch_size_GCD, args.seed, args.match_head, args.obj_direction)
    print("out_dir =", out_dir)

    to_add_other = ""

    # Build the alignment model + tokenize
    if args.alignment_metric=="BLIP":
        if args.dataset == "flickr30k":
            path_model = f"{path_checkpoints}/BLIP_models/blip_vit_b_ft_flickr30k_itr/model_base_retrieval_flickr.pth"
        elif args.dataset == "mscoco" or args.dataset.startswith("fgb_"):
            path_model = f"{path_checkpoints}/BLIP_models/blip_vit_b_ft_coco_itr/model_base_retrieval_coco.pth"
        image_size = 224
        algorithm = blip_itm(pretrained=path_model, image_size=image_size, vit='base')
        tokenizer = algorithm.tokenizer
    else:
        algorithm, tokenizer = algorithm_class_from_scratch(
            "huggingface_clip", text_base_name='openai/clip-vit-base-patch32', img_base=None, return_tokenizer=True
        )

    # Load datasets
    if args.noise_type in ["fine_grained"]:
        train_set, val_set, test_set = get_dataset(hparams['dataset'], args.seed, noisy_labels = True, percent_flips=0.0, 
                                                flip_type="random", return_combined_dataset = True)
    else:
        train_set, val_set, test_set = get_dataset(hparams['dataset'], args.seed, noisy_labels = True, percent_flips=args.noise_level, 
                                                    flip_type=args.noise_type, return_combined_dataset = True)

    if args.noise_type =="fine_grained":
        inject_fine_grained_noise(args.dataset, args.noise_level, args.seed, train_set, val_set, test_set, tokenizer, change_true=False)

    algorithm = algorithm.eval().to(device)
    
    copy_algorithm = None

    # Save the text cosine similarity for each split: train, test, val
    for dset_type in ["train", "val", "test"]:
        test_done = os.path.exists(out_dir+f'/d_cos_sim_sentences{to_add_other}_{dset_type}.pt')

        if not test_done:
            if dset_type == "train":
                dataset = train_set
            elif dset_type == "val":
                dataset = val_set
            elif dset_type == "test":
                dataset = test_set
                
            test_load = True
            try:
                d_sentences = torch.load(out_dir+f'/d_new_sentences_{dset_type}.pt', weights_only=False)
            except:
                print("Fail at "+out_dir+f'/d_new_sentences_{dset_type}.pt')
                test_load = False

            if test_load:
                l_results = run_multi_gpu_list(perform_add_score, d_sentences, n_gpus, 1, args, algorithm, tokenizer, copy_algorithm)
                d_cos_sim_sentences = {}
                if l_results[0]!={}:
                    for key in l_results[0]:
                        d_cos_sim_sentences[key] = torch.hstack([l_results[i][key] for i in range(len(l_results))])
                        
                print("Keys of d_cos_sim_sentences:", d_cos_sim_sentences.keys())

                torch.save(d_cos_sim_sentences, out_dir+f'/d_cos_sim_sentences{to_add_other}_{dset_type}.pt')
                print("Successfully saved at "+out_dir+f'/d_cos_sim_sentences{to_add_other}_{dset_type}.pt')
        else:
            print("Already saved at", out_dir+f'/d_cos_sim_sentences{to_add_other}_{dset_type}.pt')
            